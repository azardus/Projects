﻿namespace DigitalWorkshop
{
    public class Vehicle
    {
        public int NumberOfWheels;

        public int Color;

        public int NumberOfDoors;

        public int NumberOfSeats;

        public string Brand;

        private object Motor;

        public object GetMotor()
        {
            return this.Motor;
        }

        public void SetMotor(object newMotor)
        {
            // Do some things
            this.Motor = newMotor;
        }
    }
}
