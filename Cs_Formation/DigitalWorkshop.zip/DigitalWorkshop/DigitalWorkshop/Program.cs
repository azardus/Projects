﻿using System;

namespace DigitalWorkshop
{
    class Program
    {
        static void Main(string[] args)
        {
            var vehicle = new Vehicle();

            object currentMotor = vehicle.GetMotor();
            vehicle.SetMotor(null);

            Console.Read();
        }
    }
}
